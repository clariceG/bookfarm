package com.apps.bookfarm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookfarmApplicationTests {

    @Test
    void contextLoads() {
    }

}
